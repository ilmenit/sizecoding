function TIC()
  t=t+1

  cls(15)
  math.randomseed (56)
  
  for layer=14,1,-1 do
    for x=0,layer/3 do  
    -- trees
      r=math.random(240)
      rect(r+1,0,(15-layer)*1.5,136,layer)
      line(r,math.random(64),r,136,layer)
    end
    y=110-layer*4
    for x=0,240 do  
      -- ground
      line(x,y,x,136,layer)
      y=y+2*math.random()-1
      -- rain
      r=math.random(136)
      pix(x,(r+t/layer)%136,layer)
      -- small dither
      -- pix(x,r/2,pix(x,r/2)-1)
      pix(x,r,pix(x,r)-1)
      -- palette
      poke(16320+x%48,x%48*5)
    end
  end

  -- play tune
  for x=0,3 do
    sfx(
    0, -- sfx
    41+({0,3,7,8,10,12,15,3})[
     (
         (4-x)*(t//(x*64+64)+1)+(4-x)//4*4
     )%8+1
    ], -- note
    8, -- duration
    x, -- x
    (x*64+64-t)/8
    )
  end
 end
 t=0